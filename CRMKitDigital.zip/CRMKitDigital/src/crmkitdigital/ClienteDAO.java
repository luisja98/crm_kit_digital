/*
 * Nombre del programa: CRM Kit Digital
 * Autor: Luis Javier Calvo Mochales
 * Fecha: 22/05/2026
 * Descripcion: Clase DAO que gestiona las operaciones con la base de datos
 */

package crmkitdigital;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ClienteDAO {
	// Se crea el metodo para insertar clientes

	public void insertarCliente(Cliente cliente) {
		// Se crea la consulta SQL

		String sql = "INSERT INTO clientes(nombre,email,empresa,telefono,servicio_interesado) VALUES (?,?,?,?,?)";

		try {
			// Se obtiene la conexion

			Connection conexion = ConexionBD.getConnection();

			// Se prepara la consulta

			PreparedStatement sentencia = conexion.prepareStatement(sql);

			// Se asignan los valores

			sentencia.setString(1, cliente.getNombre());
			sentencia.setString(2, cliente.getEmail());
			sentencia.setString(3, cliente.getEmpresa());
			sentencia.setString(4, cliente.getTelefono());
			sentencia.setString(5, cliente.getServicioInteresado());

			// Se ejecuta la consulta

			sentencia.executeUpdate();

			// Se muestra mensaje

			System.out.println("Cliente insertado correctamente");

			// Se cierra la conexion

			conexion.close();
		} catch (SQLException e) {
			// Se muestra el error

			System.out.println("Error al insertar cliente");
			System.out.println(e.getMessage());
		}
	}

	// Se crea el metodo para listar clientes

	public ArrayList<Cliente> listarClientes() {
		// Se crea la lista

		ArrayList<Cliente> listaClientes = new ArrayList<Cliente>();

		// Se crea la consulta SQL

		String sql = "SELECT * FROM clientes";

		try {
			// Se obtiene la conexion

			Connection conexion = ConexionBD.getConnection();

			// Se prepara la consulta

			PreparedStatement sentencia = conexion.prepareStatement(sql);

			// Se ejecuta la consulta

			ResultSet resultado = sentencia.executeQuery();

			// Se recorren los resultados

			while (resultado.next()) {
				// Se crea un cliente

				Cliente cliente = new Cliente();

				// Se guardan los datos

				cliente.setIdCliente(resultado.getInt("id_cliente"));
				cliente.setNombre(resultado.getString("nombre"));
				cliente.setEmail(resultado.getString("email"));
				cliente.setEmpresa(resultado.getString("empresa"));
				cliente.setTelefono(resultado.getString("telefono"));
				cliente.setServicioInteresado(resultado.getString("servicio_interesado"));

				// Se anade el cliente a la lista

				listaClientes.add(cliente);
			}

			// Se cierra la conexion

			conexion.close();
		} catch (SQLException e) {
			// Se muestra el error

			System.out.println("Error al listar clientes");
			System.out.println(e.getMessage());
		}

		// Se devuelve la lista

		return listaClientes;
	}

	// Se crea el metodo para buscar clientes por email

	public Cliente buscarClientePorEmail(String email) {
		// Se crea la consulta SQL

		String sql = "SELECT * FROM clientes WHERE email = ?";

		try {
			// Se obtiene la conexion

			Connection conexion = ConexionBD.getConnection();

			// Se prepara la consulta

			PreparedStatement sentencia = conexion.prepareStatement(sql);

			// Se asigna el email

			sentencia.setString(1, email);

			// Se ejecuta la consulta

			ResultSet resultado = sentencia.executeQuery();

			// Se comprueba si existe

			if (resultado.next()) {
				// Se crea el cliente

				Cliente cliente = new Cliente();

				// Se guardan los datos

				cliente.setIdCliente(resultado.getInt("id_cliente"));
				cliente.setNombre(resultado.getString("nombre"));
				cliente.setEmail(resultado.getString("email"));
				cliente.setEmpresa(resultado.getString("empresa"));
				cliente.setTelefono(resultado.getString("telefono"));
				cliente.setServicioInteresado(resultado.getString("servicio_interesado"));

				// Se cierra la conexion

				conexion.close();

				// Se devuelve el cliente

				return cliente;
			}

			// Se cierra la conexion

			conexion.close();
		} catch (SQLException e) {
			// Se muestra el error

			System.out.println("Error al buscar cliente");
			System.out.println(e.getMessage());
		}

		// Se devuelve null si no existe

		return null;
	}

	// Se crea el metodo para eliminar clientes

	public void eliminarCliente(int idCliente) {
		// Se crea la consulta SQL

		String sql = "DELETE FROM clientes WHERE id_cliente = ?";

		try {
			// Se obtiene la conexion

			Connection conexion = ConexionBD.getConnection();

			// Se prepara la consulta

			PreparedStatement sentencia = conexion.prepareStatement(sql);

			// Se asigna el id

			sentencia.setInt(1, idCliente);

			// Se ejecuta la consulta

			int filas = sentencia.executeUpdate();

			// Se comprueba si se ha eliminado

			if (filas > 0) {
				System.out.println("Cliente eliminado correctamente");
			} else {
				System.out.println("No existe un cliente con ese ID");
			}

			// Se cierra la conexion

			conexion.close();
		} catch (SQLException e) {
			// Se muestra el error

			System.out.println("Error al eliminar cliente");
			System.out.println(e.getMessage());
		}
	}
}