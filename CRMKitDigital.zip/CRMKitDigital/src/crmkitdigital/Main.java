/*
 * Nombre del programa: CRM Kit Digital
 * Autor: Luis Javier Calvo Mochales
 * Fecha: 22/05/2026
 * Descripcion: Menu principal del sistema CRM Kit Digital
 */

package crmkitdigital;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		// Se crea el scanner

		Scanner lector = new Scanner(System.in);

		// Se crea el DAO

		ClienteDAO clienteDAO = new ClienteDAO();

		// Se crea la opcion del menu

		int opcion = 0;

		// Se repite el menu hasta salir

		do {
			// Se muestra el menu

			System.out.println();
			System.out.println("===== CRM KIT DIGITAL =====");
			System.out.println("1 Crear cliente");
			System.out.println("2 Ver clientes");
			System.out.println("3 Buscar cliente por email");
			System.out.println("4 Eliminar cliente");
			System.out.println("5 Salir");
			System.out.println("Elige una opcion:");

			// Se comprueba si la opcion es numerica

			if (lector.hasNextInt()) {
				opcion = lector.nextInt();
				lector.nextLine();
			} else {
				System.out.println("Debes introducir un numero");
				lector.nextLine();
				opcion = 0;
			}

			// Se comprueba la opcion elegida

			switch (opcion) {
			case 1:
				// Se crea el cliente

				Cliente cliente = new Cliente();

				// Se pide el nombre

				System.out.println("Nombre:");
				cliente.setNombre(lector.nextLine());

				// Se pide el email

				System.out.println("Email:");
				cliente.setEmail(lector.nextLine());

				// Se pide la empresa

				System.out.println("Empresa:");
				cliente.setEmpresa(lector.nextLine());

				// Se pide el telefono

				System.out.println("Telefono:");
				cliente.setTelefono(lector.nextLine());

				// Se pide el servicio interesado

				System.out.println("Servicio interesado:");
				cliente.setServicioInteresado(lector.nextLine());

				// Se comprueba que los campos obligatorios no esten vacios

				if (cliente.getNombre().isEmpty() || cliente.getEmail().isEmpty() || cliente.getEmpresa().isEmpty()
						|| cliente.getServicioInteresado().isEmpty()) {
					System.out.println("Los campos nombre, email, empresa y servicio son obligatorios");
				} else {
					clienteDAO.insertarCliente(cliente);
				}

				break;

			case 2:
				// Se obtiene la lista de clientes

				ArrayList<Cliente> listaClientes = clienteDAO.listarClientes();

				// Se comprueba si la lista esta vacia

				if (listaClientes.isEmpty()) {
					System.out.println("No hay clientes registrados");
				} else {
					// Se muestran los clientes

					for (Cliente c : listaClientes) {
						System.out.println(c);
					}
				}

				break;

			case 3:
				// Se pide el email

				System.out.println("Introduce el email del cliente:");

				String emailBuscar = lector.nextLine();

				// Se busca el cliente

				Cliente clienteBuscado = clienteDAO.buscarClientePorEmail(emailBuscar);

				// Se muestra el resultado

				if (clienteBuscado == null) {
					System.out.println("No existe ningun cliente con ese email");
				} else {
					System.out.println(clienteBuscado);
				}

				break;

			case 4:
				// Se pide el id

				System.out.println("Introduce el ID del cliente a eliminar:");

				// Se comprueba si el id es numerico

				if (lector.hasNextInt()) {
					int idEliminar = lector.nextInt();
					lector.nextLine();

					// Se comprueba que el id sea positivo

					if (idEliminar > 0) {
						clienteDAO.eliminarCliente(idEliminar);
					} else {
						System.out.println("El ID debe ser mayor que 0");
					}
				} else {
					System.out.println("Debes introducir un numero");
					lector.nextLine();
				}

				break;

			case 5:
				// Se muestra mensaje de salida

				System.out.println("Saliendo del programa");

				break;

			default:
				// Se muestra mensaje de error

				if (opcion != 0) {
					System.out.println("Opcion incorrecta");
				}

				break;
			}

		} while (opcion != 5);

		// Se cierra el scanner

		lector.close();
	}
}