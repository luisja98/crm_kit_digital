/*
 * Nombre del programa: CRM Kit Digital
 * Autor: Luis Javier Calvo Mochales
 * Fecha: 22/05/2026
 * Descripcion: Clase encargada de conectar Java con MySQL
 */

package crmkitdigital;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {
	// Se crea la URL de la base de datos

	private static final String URL = "jdbc:mysql://localhost:3306/crm_kit_digital";

	// Se crea el usuario de MySQL

	private static final String USUARIO = "root";

	// Se crea la contrasena de MySQL

	private static final String PASSWORD = "root";

	// Se crea el metodo para obtener la conexion

	public static Connection getConnection() throws SQLException {
		return DriverManager.getConnection(URL, USUARIO, PASSWORD);
	}
}