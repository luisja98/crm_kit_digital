/*
 * Nombre del programa: CRM Kit Digital
 * Autor: Luis Javier Calvo Mochales
 * Fecha: 22/05/2026
 * Descripcion: Clase modelo que representa un cliente
 */

package crmkitdigital;

public class Cliente {
	// Se crean los atributos del cliente

	private int idCliente;
	private String nombre;
	private String email;
	private String empresa;
	private String telefono;
	private String servicioInteresado;

	// Se crea el constructor vacio

	public Cliente() {

	}

	// Se crea el constructor completo

	public Cliente(int idCliente, String nombre, String email, String empresa, String telefono,
			String servicioInteresado) {
		this.idCliente = idCliente;
		this.nombre = nombre;
		this.email = email;
		this.empresa = empresa;
		this.telefono = telefono;
		this.servicioInteresado = servicioInteresado;
	}

	// Se obtiene el id del cliente

	public int getIdCliente() {
		return idCliente;
	}

	// Se modifica el id del cliente

	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}

	// Se obtiene el nombre

	public String getNombre() {
		return nombre;
	}

	// Se modifica el nombre

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	// Se obtiene el email

	public String getEmail() {
		return email;
	}

	// Se modifica el email

	public void setEmail(String email) {
		this.email = email;
	}

	// Se obtiene la empresa

	public String getEmpresa() {
		return empresa;
	}

	// Se modifica la empresa

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	// Se obtiene el telefono

	public String getTelefono() {
		return telefono;
	}

	// Se modifica el telefono

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	// Se obtiene el servicio interesado

	public String getServicioInteresado() {
		return servicioInteresado;
	}

	// Se modifica el servicio interesado

	public void setServicioInteresado(String servicioInteresado) {
		this.servicioInteresado = servicioInteresado;
	}

	// Se muestra la informacion del cliente

	@Override
	public String toString() {
		return "ID: " + idCliente + " | Nombre: " + nombre + " | Email: " + email + " | Empresa: " + empresa
				+ " | Telefono: " + telefono + " | Servicio: " + servicioInteresado;
	}
}